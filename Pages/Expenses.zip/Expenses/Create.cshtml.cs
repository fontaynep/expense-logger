using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ExpenseLogger.Data;
using ExpenseLogger.Models;

namespace ExpenseLogger.Pages.Expenses
    {
    public class CreateModel : PageModel
    {
        private readonly ExpenseLogger.Data.AppDbContext _context;

        public CreateModel(ExpenseLogger.Data.AppDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Expense Expense { get; set; } = default!;

        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
            {
            if (!ModelState.IsValid)
                {
                foreach (var state in ModelState)
                    {
                    foreach (var error in state.Value.Errors)
                        {
                        Console.WriteLine($"Model Error - {state.Key}: {error.ErrorMessage}");
                        }
                    }
                return Page();
                }

            _context.Expenses.Add(Expense);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
            }

        }
    }
